import { AlertTriangle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface AlertBannerProps {
  aqi: number;
  city: string;
}

const AlertBanner = ({ aqi, city }: AlertBannerProps) => {
  const [isVisible, setIsVisible] = useState(true);

  if (aqi <= 150 || !isVisible) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-2xl w-full px-4">
      <div className="glass-panel bg-destructive/20 border-destructive/50 p-4 glow-effect">
        <div className="flex items-start gap-3">
          <AlertTriangle className="text-destructive flex-shrink-0 mt-0.5" size={24} />
          <div className="flex-1">
            <h3 className="font-bold text-destructive mb-1">High Air Quality Alert</h3>
            <p className="text-sm text-foreground">
              {city} is experiencing unhealthy air quality (AQI: {aqi}). 
              Consider limiting outdoor activities and staying indoors.
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsVisible(false)}
            className="flex-shrink-0"
          >
            <X size={20} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AlertBanner;
