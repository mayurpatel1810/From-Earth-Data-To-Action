import { Search, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SearchBarProps {
  onSearch: (city: string) => void;
  value: string;
  onChange: (value: string) => void;
  onLocationRequest: () => void;
  isLoadingLocation?: boolean;
}

const SearchBar = ({ onSearch, value, onChange, onLocationRequest, isLoadingLocation }: SearchBarProps) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onSearch(value.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl">
      <div className="glass-panel p-4 glow-effect">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              type="text"
              placeholder="Search for a city in North America..."
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="pl-10 bg-background/50 border-border text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <Button 
            type="button"
            variant="outline"
            className="glass-panel border-primary/20 hover:border-primary/50"
            onClick={onLocationRequest}
            disabled={isLoadingLocation}
            title="Use my location"
          >
            <MapPin className={`w-5 h-5 ${isLoadingLocation ? 'animate-pulse' : ''}`} />
          </Button>
          <Button type="submit" className="glow-effect">
            Search
          </Button>
        </div>
      </div>
    </form>
  );
};

export default SearchBar;
