import { useRef, useEffect } from 'react';
import { useFrame, useLoader } from '@react-three/fiber';
import { TextureLoader } from 'three';
import * as THREE from 'three';

interface EarthProps {
  isZoomed: boolean;
}

const Earth = ({ isZoomed }: EarthProps) => {
  const earthRef = useRef<THREE.Mesh>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  
  // Using a simple color map for the earth texture
  const earthTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;
    
    // Create ocean gradient
    const oceanGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    oceanGradient.addColorStop(0, '#1a3a52');
    oceanGradient.addColorStop(0.5, '#2a5a7a');
    oceanGradient.addColorStop(1, '#1a3a52');
    ctx.fillStyle = oceanGradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add land masses (simplified continents)
    ctx.fillStyle = '#2d5a3d';
    
    // North America (simplified)
    ctx.beginPath();
    ctx.ellipse(400, 300, 200, 250, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // South America
    ctx.beginPath();
    ctx.ellipse(500, 600, 120, 180, 0.3, 0, Math.PI * 2);
    ctx.fill();
    
    // Europe/Africa
    ctx.beginPath();
    ctx.ellipse(1000, 400, 180, 300, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Asia
    ctx.beginPath();
    ctx.ellipse(1400, 300, 300, 200, 0, 0, Math.PI * 2);
    ctx.fill();
    
    return new THREE.CanvasTexture(canvas);
  }, []);
  
  useFrame((state) => {
    if (!earthRef.current || !cloudsRef.current) return;
    
    if (!isZoomed) {
      earthRef.current.rotation.y += 0.001;
      cloudsRef.current.rotation.y += 0.0012;
    }
  });
  
  useEffect(() => {
    if (!earthRef.current) return;
    
    // Animate zoom to North America
    if (isZoomed) {
      // Rotate to show North America (roughly -100° longitude, 40° latitude)
      const targetRotationY = (100 * Math.PI) / 180;
      const targetRotationX = (-40 * Math.PI) / 180;
      
      const animateRotation = () => {
        if (!earthRef.current || !cloudsRef.current) return;
        
        earthRef.current.rotation.y += (targetRotationY - earthRef.current.rotation.y) * 0.05;
        earthRef.current.rotation.x += (targetRotationX - earthRef.current.rotation.x) * 0.05;
        cloudsRef.current.rotation.y = earthRef.current.rotation.y + 0.01;
        cloudsRef.current.rotation.x = earthRef.current.rotation.x;
        
        if (
          Math.abs(targetRotationY - earthRef.current.rotation.y) > 0.01 ||
          Math.abs(targetRotationX - earthRef.current.rotation.x) > 0.01
        ) {
          requestAnimationFrame(animateRotation);
        }
      };
      
      animateRotation();
    }
  }, [isZoomed]);
  
  return (
    <group>
      {/* Earth */}
      <mesh ref={earthRef}>
        <sphereGeometry args={[5, 64, 64]} />
        <meshPhongMaterial
          map={earthTexture}
          emissive="#0a1a2a"
          emissiveIntensity={0.1}
          shininess={10}
        />
      </mesh>
      
      {/* Clouds */}
      <mesh ref={cloudsRef}>
        <sphereGeometry args={[5.05, 64, 64]} />
        <meshPhongMaterial
          transparent
          opacity={0.2}
          color="#ffffff"
          emissive="#ffffff"
          emissiveIntensity={0.1}
        />
      </mesh>
      
      {/* Atmosphere glow */}
      <mesh>
        <sphereGeometry args={[5.3, 64, 64]} />
        <meshBasicMaterial
          color="#4a9eff"
          transparent
          opacity={0.1}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  );
};

import { useMemo } from 'react';

export default Earth;
