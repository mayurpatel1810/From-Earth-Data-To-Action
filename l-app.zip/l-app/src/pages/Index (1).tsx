import { useState, useEffect, Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, PerspectiveCamera } from "@react-three/drei";
import Earth from "@/components/Earth";
import StarField from "@/components/StarField";
import SearchBar from "@/components/SearchBar";
import DataPanel from "@/components/DataPanel";
import ForecastChart from "@/components/ForecastChart";
import AlertBanner from "@/components/AlertBanner";
import { toast } from "sonner";
import {
  fetchWeatherData,
  fetchAQIData,
  generateForecast,
  getCityCoordinates,
  getAvailableCities,
} from "@/utils/airQualityAPI";

interface PollutantData {
  o3?: number;
  no2?: number;
  so2?: number;
  co?: number;
  pm25?: number;
  pm10?: number;
}

interface AirQualityData {
  city: string;
  aqi: number;
  temperature: number;
  humidity: number;
  windSpeed: number;
  pollutants?: PollutantData;
}

interface ForecastData {
  day: string;
  aqi: number;
}

const Index = () => {
  const [searchValue, setSearchValue] = useState("");
  const [isZoomed, setIsZoomed] = useState(false);
  const [airQualityData, setAirQualityData] = useState<AirQualityData | null>(null);
  const [forecastData, setForecastData] = useState<ForecastData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  const fetchDataForCoordinates = async (lat: number, lon: number, locationName: string) => {
    setIsLoading(true);
    
    try {
      // Zoom to North America
      setIsZoomed(true);
      
      // Fetch data in parallel
      const [weatherData, aqiData] = await Promise.all([
        fetchWeatherData(lat, lon),
        fetchAQIData(lat, lon),
      ]);

      const data: AirQualityData = {
        city: locationName,
        aqi: aqiData.aqi,
      temperature: weatherData.temperature,
      humidity: weatherData.humidity,
      windSpeed: weatherData.windSpeed,
      pollutants: aqiData.pollutants,
      };

      setAirQualityData(data);
      setForecastData(generateForecast(aqiData.aqi));
      
      toast.success(`Data loaded for ${locationName}`);
    } catch (error) {
      toast.error("Failed to fetch data. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = async (cityName: string) => {
    const coords = getCityCoordinates(cityName);
    
    if (!coords) {
      toast.error(`City not found. Try one of these cities: ${getAvailableCities().slice(0, 5).join(', ')}...`);
      return;
    }

    await fetchDataForCoordinates(coords.lat, coords.lon, cityName);
  };

  const handleLocationRequest = () => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser");
      return;
    }

    setIsLoadingLocation(true);
    toast.info("Getting your location...");

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setIsLoadingLocation(false);
        
        // Format coordinates for display
        const locationName = `Your Location (${latitude.toFixed(2)}°, ${longitude.toFixed(2)}°)`;
        
        await fetchDataForCoordinates(latitude, longitude, locationName);
      },
      (error) => {
        setIsLoadingLocation(false);
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            toast.error("Location permission denied. Please enable location access.");
            break;
          case error.POSITION_UNAVAILABLE:
            toast.error("Location information is unavailable.");
            break;
          case error.TIMEOUT:
            toast.error("Location request timed out.");
            break;
          default:
            toast.error("An error occurred while getting your location.");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  useEffect(() => {
    // Show welcome message
    toast.info("Search for a North American city to view air quality data");
  }, []);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Alert Banner */}
      {airQualityData && airQualityData.aqi > 150 && (
        <AlertBanner aqi={airQualityData.aqi} city={airQualityData.city} />
      )}

      {/* 3D Canvas Background */}
      <div className="fixed inset-0 z-0">
        <Canvas>
          <Suspense fallback={null}>
            <PerspectiveCamera makeDefault position={[0, 0, isZoomed ? 10 : 20]} />
            <OrbitControls
              enableZoom
              enablePan={false}
              minDistance={8}
              maxDistance={30}
              autoRotate={!isZoomed}
              autoRotateSpeed={0.5}
            />
            
            {/* Lighting */}
            <ambientLight intensity={0.3} />
            <directionalLight position={[10, 10, 5]} intensity={1} />
            <pointLight position={[-10, -10, -5]} intensity={0.5} color="#4a9eff" />
            
            {/* Scene */}
            <StarField />
            <Earth isZoomed={isZoomed} />
          </Suspense>
        </Canvas>
      </div>

      {/* UI Overlay */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Header */}
        <header className="p-6">
          <div className="text-center mb-8">
            <h1 className="text-5xl md:text-6xl font-bold text-glow mb-2">
              TEMPO Air Quality Monitor
            </h1>
            <p className="text-lg text-muted-foreground">
              Real-time air quality data across North America
            </p>
          </div>

          {/* Search Bar */}
          <div className="flex justify-center">
            <SearchBar
              value={searchValue}
              onChange={setSearchValue}
              onSearch={handleSearch}
              onLocationRequest={handleLocationRequest}
              isLoadingLocation={isLoadingLocation}
            />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 container mx-auto px-4 pb-8">
          {isLoading ? (
            <div className="glass-panel p-8 text-center glow-effect">
              <div className="animate-pulse">
                <p className="text-xl">Loading air quality data...</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column - Current Data */}
              <div>
                <DataPanel data={airQualityData} />
              </div>

              {/* Right Column - Forecast */}
              <div>
                {forecastData.length > 0 && (
                  <ForecastChart data={forecastData} />
                )}
              </div>
            </div>
          )}

          {/* Info Section */}
          {!airQualityData && !isLoading && (
            <div className="mt-8 glass-panel p-6 max-w-3xl mx-auto">
              <h2 className="text-2xl font-bold mb-4 text-glow">About TEMPO</h2>
              <p className="text-muted-foreground mb-4">
                NASA's TEMPO (Tropospheric Emissions: Monitoring of Pollution) mission provides 
                hourly daytime observations of air quality over North America. This tool combines 
                TEMPO satellite data with ground-based measurements and weather data to give you 
                accurate, real-time air quality information.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">40%</div>
                  <div className="text-muted-foreground">TEMPO Data</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">50%</div>
                  <div className="text-muted-foreground">Ground Data</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">10%</div>
                  <div className="text-muted-foreground">Weather</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">15+</div>
                  <div className="text-muted-foreground">Cities</div>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="p-4 text-center text-sm text-muted-foreground">
          <p>Data sources: NASA TEMPO, OpenAQ, Open-Meteo • Built for NASA Space Apps Challenge</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
