import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";

interface ForecastData {
  day: string;
  aqi: number;
}

interface ForecastChartProps {
  data: ForecastData[];
}

const getAQIColor = (aqi: number): string => {
  if (aqi <= 50) return "#4ade80";
  if (aqi <= 100) return "#fbbf24";
  if (aqi <= 150) return "#fb923c";
  if (aqi <= 200) return "#ef4444";
  if (aqi <= 300) return "#a855f7";
  return "#7f1d1d";
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const aqi = payload[0].value;
    return (
      <div className="glass-panel p-3">
        <p className="font-semibold">{payload[0].payload.day}</p>
        <p style={{ color: getAQIColor(aqi) }}>
          AQI: {aqi}
        </p>
      </div>
    );
  }
  return null;
};

const ForecastChart = ({ data }: ForecastChartProps) => {
  return (
    <Card className="glass-panel border-0 glow-effect">
      <CardHeader>
        <CardTitle className="text-xl text-glow">5-Day AQI Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="aqiGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="day" 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '12px' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="aqi"
              stroke="hsl(var(--primary))"
              strokeWidth={3}
              fill="url(#aqiGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
        
        {/* AQI Legend */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(25) }} />
            <span>Good (0-50)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(75) }} />
            <span>Moderate (51-100)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(125) }} />
            <span>Sensitive (101-150)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(175) }} />
            <span>Unhealthy (151-200)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(250) }} />
            <span>Very Unhealthy (201-300)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: getAQIColor(350) }} />
            <span>Hazardous (301+)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ForecastChart;
