interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
}

interface PollutantData {
  o3?: number;
  no2?: number;
  so2?: number;
  co?: number;
  pm25?: number;
  pm10?: number;
}

interface AQIData {
  aqi: number;
  groundAQI: number;
  tempoAQI: number;
  pollutants: PollutantData;
}

interface ForecastDay {
  day: string;
  aqi: number;
}

// City coordinates for North American cities
const cityCoordinates: Record<string, { lat: number; lon: number }> = {
  "new york": { lat: 40.7128, lon: -74.0060 },
  "los angeles": { lat: 34.0522, lon: -118.2437 },
  "chicago": { lat: 41.8781, lon: -87.6298 },
  "houston": { lat: 29.7604, lon: -95.3698 },
  "phoenix": { lat: 33.4484, lon: -112.0740 },
  "toronto": { lat: 43.6532, lon: -79.3832 },
  "vancouver": { lat: 49.2827, lon: -123.1207 },
  "mexico city": { lat: 19.4326, lon: -99.1332 },
  "miami": { lat: 25.7617, lon: -80.1918 },
  "seattle": { lat: 47.6062, lon: -122.3321 },
  "denver": { lat: 39.7392, lon: -104.9903 },
  "boston": { lat: 42.3601, lon: -71.0589 },
  "atlanta": { lat: 33.7490, lon: -84.3880 },
  "dallas": { lat: 32.7767, lon: -96.7970 },
  "san francisco": { lat: 37.7749, lon: -122.4194 },
};

// Mock TEMPO satellite data (in a real app, this would come from NASA's API)
const getMockTEMPOData = (lat: number, lon: number): number => {
  // Simulate TEMPO AQI based on location
  const baseAQI = 40 + Math.random() * 60;
  const latitudeFactor = Math.abs(lat - 35) * 0.5; // Cities closer to 35°N have different pollution
  return Math.round(baseAQI + latitudeFactor);
};

// Fetch weather data from Open-Meteo API
export const fetchWeatherData = async (lat: number, lon: number): Promise<WeatherData> => {
  try {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m`
    );
    
    if (!response.ok) throw new Error('Weather API failed');
    
    const data = await response.json();
    
    return {
      temperature: Math.round(data.current.temperature_2m),
      humidity: Math.round(data.current.relative_humidity_2m),
      windSpeed: Math.round(data.current.wind_speed_10m * 10) / 10,
    };
  } catch (error) {
    console.error('Weather API error:', error);
    // Return mock data on error
    return {
      temperature: 20 + Math.round(Math.random() * 15),
      humidity: 40 + Math.round(Math.random() * 40),
      windSpeed: Math.round((2 + Math.random() * 8) * 10) / 10,
    };
  }
};

// Fetch AQI data from OpenAQ API
export const fetchAQIData = async (lat: number, lon: number): Promise<AQIData> => {
  try {
    // OpenAQ API v3 endpoint
    const radius = 50000; // 50km radius
    const response = await fetch(
      `https://api.openaq.org/v3/latest?coordinates=${lat},${lon}&radius=${radius}&limit=10`,
      {
        headers: {
          'Accept': 'application/json',
        }
      }
    );
    
    if (!response.ok) throw new Error('AQI API failed');
    
    const data = await response.json();
    
    // Extract pollutant data
    const pollutants: PollutantData = {};
    let groundAQI = 50;
    
    if (data.results && data.results.length > 0) {
      const parameterValues: Record<string, number[]> = {};
      
      data.results.forEach((r: any) => {
        if (!parameterValues[r.parameter]) {
          parameterValues[r.parameter] = [];
        }
        parameterValues[r.parameter].push(r.value);
      });
      
      // Calculate averages for each pollutant
      Object.keys(parameterValues).forEach(param => {
        const values = parameterValues[param];
        const avg = values.reduce((a, b) => a + b, 0) / values.length;
        
        switch(param) {
          case 'o3':
            pollutants.o3 = Math.round(avg);
            break;
          case 'no2':
            pollutants.no2 = Math.round(avg);
            break;
          case 'so2':
            pollutants.so2 = Math.round(avg);
            break;
          case 'co':
            pollutants.co = Math.round(avg * 10) / 10;
            break;
          case 'pm25':
            pollutants.pm25 = Math.round(avg);
            groundAQI = Math.round(avg * 2.5);
            break;
          case 'pm10':
            pollutants.pm10 = Math.round(avg);
            break;
        }
      });
    }
    
    // Get mock TEMPO data
    const tempoAQI = getMockTEMPOData(lat, lon);
    
    // Simulate weather factor (simplified)
    const weatherFactor = 0.1;
    
    // Blend data: 0.4*TEMPO + 0.5*Ground + 0.1*Weather
    const finalAQI = Math.round(
      0.4 * tempoAQI + 0.5 * groundAQI + weatherFactor * 100
    );
    
    return {
      aqi: Math.min(500, Math.max(0, finalAQI)),
      groundAQI,
      tempoAQI,
      pollutants,
    };
  } catch (error) {
    console.error('AQI API error:', error);
    // Return mock data on error
    const tempoAQI = getMockTEMPOData(lat, lon);
    const groundAQI = 40 + Math.round(Math.random() * 80);
    return {
      aqi: Math.round(0.4 * tempoAQI + 0.5 * groundAQI + 0.1 * 50),
      groundAQI,
      tempoAQI,
      pollutants: {
        pm25: 30 + Math.round(Math.random() * 40),
        pm10: 40 + Math.round(Math.random() * 60),
        o3: 20 + Math.round(Math.random() * 50),
        no2: 15 + Math.round(Math.random() * 35),
        so2: 5 + Math.round(Math.random() * 20),
        co: Math.round((0.3 + Math.random() * 0.7) * 10) / 10,
      },
    };
  }
};

// Generate 5-day forecast
export const generateForecast = (currentAQI: number): ForecastDay[] => {
  const days = ['Today', 'Tomorrow', 'Day 3', 'Day 4', 'Day 5'];
  const forecast: ForecastDay[] = [];
  
  let baseAQI = currentAQI;
  
  for (let i = 0; i < 5; i++) {
    // Simulate AQI variation over days
    const variation = (Math.random() - 0.5) * 30;
    const dayAQI = Math.round(Math.max(0, Math.min(500, baseAQI + variation)));
    
    forecast.push({
      day: days[i],
      aqi: dayAQI,
    });
    
    baseAQI = dayAQI;
  }
  
  return forecast;
};

// Get city coordinates
export const getCityCoordinates = (cityName: string): { lat: number; lon: number } | null => {
  const normalizedCity = cityName.toLowerCase().trim();
  return cityCoordinates[normalizedCity] || null;
};

// Get all available cities
export const getAvailableCities = (): string[] => {
  return Object.keys(cityCoordinates).map(city => 
    city.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')
  );
};
